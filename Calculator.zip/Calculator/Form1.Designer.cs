﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Reset = new System.Windows.Forms.Button();
            this.PlusMinus = new System.Windows.Forms.Button();
            this.Percent = new System.Windows.Forms.Button();
            this.Devide = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.Times = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Minus = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Equals = new System.Windows.Forms.Button();
            this.Number = new System.Windows.Forms.Label();
            this.Zero = new System.Windows.Forms.Button();
            this.FullStop = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Background = new System.Windows.Forms.Panel();
            this.Background.SuspendLayout();
            this.SuspendLayout();
            // 
            // Reset
            // 
            this.Reset.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Reset.Location = new System.Drawing.Point(16, 21);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(100, 100);
            this.Reset.TabIndex = 1;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // PlusMinus
            // 
            this.PlusMinus.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PlusMinus.Location = new System.Drawing.Point(122, 21);
            this.PlusMinus.Name = "PlusMinus";
            this.PlusMinus.Size = new System.Drawing.Size(100, 100);
            this.PlusMinus.TabIndex = 2;
            this.PlusMinus.Text = "+/-";
            this.PlusMinus.UseVisualStyleBackColor = true;
            this.PlusMinus.Click += new System.EventHandler(this.PlusMinus_Click);
            // 
            // Percent
            // 
            this.Percent.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Percent.Location = new System.Drawing.Point(228, 21);
            this.Percent.Name = "Percent";
            this.Percent.Size = new System.Drawing.Size(100, 100);
            this.Percent.TabIndex = 3;
            this.Percent.Text = "%";
            this.Percent.UseVisualStyleBackColor = true;
            this.Percent.Click += new System.EventHandler(this.Percent_Click);
            // 
            // Devide
            // 
            this.Devide.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Devide.Location = new System.Drawing.Point(334, 21);
            this.Devide.Name = "Devide";
            this.Devide.Size = new System.Drawing.Size(100, 100);
            this.Devide.TabIndex = 4;
            this.Devide.Text = "÷";
            this.Devide.UseVisualStyleBackColor = true;
            this.Devide.Click += new System.EventHandler(this.Devide_Click);
            // 
            // Seven
            // 
            this.Seven.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Seven.Location = new System.Drawing.Point(16, 127);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(100, 100);
            this.Seven.TabIndex = 5;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = true;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Eight
            // 
            this.Eight.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Eight.Location = new System.Drawing.Point(122, 127);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(100, 100);
            this.Eight.TabIndex = 6;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = true;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Nine
            // 
            this.Nine.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Nine.Location = new System.Drawing.Point(228, 127);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(100, 100);
            this.Nine.TabIndex = 7;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = true;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // Times
            // 
            this.Times.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Times.Location = new System.Drawing.Point(334, 127);
            this.Times.Name = "Times";
            this.Times.Size = new System.Drawing.Size(100, 100);
            this.Times.TabIndex = 8;
            this.Times.Text = "x";
            this.Times.UseVisualStyleBackColor = true;
            this.Times.Click += new System.EventHandler(this.Times_Click);
            // 
            // Four
            // 
            this.Four.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Four.Location = new System.Drawing.Point(16, 233);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(100, 100);
            this.Four.TabIndex = 9;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = true;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // Five
            // 
            this.Five.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Five.Location = new System.Drawing.Point(122, 233);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(100, 100);
            this.Five.TabIndex = 10;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = true;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Six
            // 
            this.Six.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Six.Location = new System.Drawing.Point(228, 233);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(100, 100);
            this.Six.TabIndex = 11;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = true;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // Minus
            // 
            this.Minus.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Minus.Location = new System.Drawing.Point(334, 233);
            this.Minus.Name = "Minus";
            this.Minus.Size = new System.Drawing.Size(100, 100);
            this.Minus.TabIndex = 12;
            this.Minus.Text = "-";
            this.Minus.UseVisualStyleBackColor = true;
            this.Minus.Click += new System.EventHandler(this.Minus_Click);
            // 
            // One
            // 
            this.One.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.One.Location = new System.Drawing.Point(16, 339);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(100, 100);
            this.One.TabIndex = 13;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = true;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // Two
            // 
            this.Two.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Two.Location = new System.Drawing.Point(122, 339);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(100, 100);
            this.Two.TabIndex = 14;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = true;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // Three
            // 
            this.Three.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Three.Location = new System.Drawing.Point(228, 339);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(100, 100);
            this.Three.TabIndex = 15;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = true;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // Equals
            // 
            this.Equals.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Equals.Location = new System.Drawing.Point(334, 445);
            this.Equals.Name = "Equals";
            this.Equals.Size = new System.Drawing.Size(100, 100);
            this.Equals.TabIndex = 16;
            this.Equals.Text = "=";
            this.Equals.UseVisualStyleBackColor = true;
            this.Equals.Click += new System.EventHandler(this.Equals_Click);
            // 
            // Number
            // 
            this.Number.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Number.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Number.Font = new System.Drawing.Font("Roboto Medium", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Number.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.Number.Location = new System.Drawing.Point(12, 9);
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(450, 115);
            this.Number.TabIndex = 17;
            this.Number.Text = "0000000";
            this.Number.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Zero
            // 
            this.Zero.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Zero.Location = new System.Drawing.Point(16, 445);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(206, 100);
            this.Zero.TabIndex = 18;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = true;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // FullStop
            // 
            this.FullStop.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FullStop.Location = new System.Drawing.Point(228, 445);
            this.FullStop.Name = "FullStop";
            this.FullStop.Size = new System.Drawing.Size(100, 100);
            this.FullStop.TabIndex = 19;
            this.FullStop.Text = ".";
            this.FullStop.UseVisualStyleBackColor = true;
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("Roboto Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(334, 339);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(100, 100);
            this.Add.TabIndex = 20;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Background
            // 
            this.Background.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Background.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Background.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Background.Controls.Add(this.Add);
            this.Background.Controls.Add(this.Six);
            this.Background.Controls.Add(this.FullStop);
            this.Background.Controls.Add(this.Reset);
            this.Background.Controls.Add(this.Zero);
            this.Background.Controls.Add(this.PlusMinus);
            this.Background.Controls.Add(this.Percent);
            this.Background.Controls.Add(this.Equals);
            this.Background.Controls.Add(this.Devide);
            this.Background.Controls.Add(this.Three);
            this.Background.Controls.Add(this.Seven);
            this.Background.Controls.Add(this.Two);
            this.Background.Controls.Add(this.Eight);
            this.Background.Controls.Add(this.One);
            this.Background.Controls.Add(this.Nine);
            this.Background.Controls.Add(this.Minus);
            this.Background.Controls.Add(this.Times);
            this.Background.Controls.Add(this.Four);
            this.Background.Controls.Add(this.Five);
            this.Background.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Background.Location = new System.Drawing.Point(12, 127);
            this.Background.Name = "Background";
            this.Background.Size = new System.Drawing.Size(450, 562);
            this.Background.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 701);
            this.Controls.Add(this.Number);
            this.Controls.Add(this.Background);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Background.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Button Reset;
        private Button PlusMinus;
        private Button Percent;
        private Button Devide;
        private Button Seven;
        private Button Eight;
        private Button Nine;
        private Button Times;
        private Button Four;
        private Button Five;
        private Button Six;
        private Button Minus;
        private Button One;
        private Button Two;
        private Button Three;
        private Button Equals;
        private Label Number;
        private Button Zero;
        private Button FullStop;
        private Button Add;
        private Panel Background;
    }
}